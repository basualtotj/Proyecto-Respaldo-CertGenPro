Backup Directory
================

This directory contains database backups created by the admin panel.

Files are automatically generated with timestamp format: backup_YYYY-MM-DD_HH-mm-ss.sql

Security Note: In production, ensure this directory is not accessible via web.
