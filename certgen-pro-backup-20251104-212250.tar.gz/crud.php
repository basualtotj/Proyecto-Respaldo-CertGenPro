<?php
session_start();
if (!isset($_SESSION["user_id"])) {
    header("Location: login.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD - Gestión de Datos</title>
    
    <!-- TailwindCSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Font Awesome Icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    
    <!-- Componente de navegación global -->
    <script src="js/components/navbar.js"></script>
    <style>
        /* Estilos personalizados para el modal */
        .modal-content {
            max-height: calc(100vh - 8rem);
        }
        
        /* Mejorar los formularios largos */
        .form-grid-lg {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }
        
        .form-full-width {
            grid-column: span 2;
        }
        
        @media (max-width: 768px) {
            .form-grid-lg {
                grid-template-columns: 1fr;
            }
            .form-full-width {
                grid-column: span 1;
            }
        }
    </style>
</head>
<body class="bg-gray-50 min-h-screen">

    <div class="container mx-auto p-6 pt-6">
        <!-- Tabs -->
        <div class="mb-6">
            <div class="flex border-b">
                <button id="clientesTab" class="tab-button active px-6 py-3 border-b-2 border-blue-500 text-blue-600 font-semibold">
                    <i class="fas fa-users mr-2"></i>Clientes
                </button>
                <button id="instalacionesTab" class="tab-button px-6 py-3 text-gray-600 hover:text-blue-600 transition-colors">
                    <i class="fas fa-building mr-2"></i>Instalaciones
                </button>
                <button id="tecnicosTab" class="tab-button px-6 py-3 text-gray-600 hover:text-blue-600 transition-colors">
                    <i class="fas fa-user-cog mr-2"></i>Técnicos
                </button>
                <button id="empresaTab" class="tab-button px-6 py-3 text-gray-600 hover:text-blue-600 transition-colors">
                    <i class="fas fa-briefcase mr-2"></i>Empresa
                </button>
            </div>
        </div>

        <!-- Content Panels -->
        <div id="clientesPanel" class="tab-panel">
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex justify-between items-center mb-6">
                    <h2 class="text-2xl font-bold text-gray-800">Gestión de Clientes</h2>
                    <button id="addClienteBtn" class="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg transition-colors">
                        <i class="fas fa-plus mr-2"></i>Nuevo Cliente
                    </button>
                </div>

                <!-- Search and Filter -->
                <div class="mb-4 flex space-x-4">
                    <div class="flex-1">
                        <input type="text" id="searchClientes" placeholder="Buscar clientes..." 
                               class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                    </div>
                    <button id="refreshClientesBtn" class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg transition-colors">
                        <i class="fas fa-refresh"></i>
                    </button>
                </div>

                <!-- Clients Table -->
                <div class="overflow-x-auto">
                    <table class="w-full table-auto">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nombre</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">RUT</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Contacto</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Teléfono</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Acciones</th>
                            </tr>
                        </thead>
                        <tbody id="clientesTableBody" class="bg-white divide-y divide-gray-200">
                            <!-- Clients will be loaded here -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div id="instalacionesPanel" class="tab-panel hidden">
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex justify-between items-center mb-6">
                    <h2 class="text-2xl font-bold text-gray-800">Gestión de Instalaciones</h2>
                    <button id="addInstalacionBtn" class="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg transition-colors">
                        <i class="fas fa-plus mr-2"></i>Nueva Instalación
                    </button>
                </div>

                <!-- Installations content -->
                <div class="overflow-x-auto">
                    <table class="w-full table-auto">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Cliente</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nombre</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Dirección</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Contacto</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Teléfono</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tipo</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Acciones</th>
                            </tr>
                        </thead>
                        <tbody id="instalacionesTableBody" class="bg-white divide-y divide-gray-200">
                            <!-- Installations will be loaded here -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div id="tecnicosPanel" class="tab-panel hidden">
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex justify-between items-center mb-6">
                    <h2 class="text-2xl font-bold text-gray-800">Gestión de Técnicos</h2>
                    <button id="addTecnicoBtn" class="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg transition-colors">
                        <i class="fas fa-plus mr-2"></i>Nuevo Técnico
                    </button>
                </div>

                <!-- Technicians content -->
                <div class="overflow-x-auto">
                    <table class="w-full table-auto">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nombre</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Especialidad</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Teléfono</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Estado</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Acciones</th>
                            </tr>
                        </thead>
                        <tbody id="tecnicosTableBody" class="bg-white divide-y divide-gray-200">
                            <!-- Technicians will be loaded here -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div id="empresaPanel" class="tab-panel hidden">
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex justify-between items-center mb-6">
                    <h2 class="text-2xl font-bold text-gray-800">Datos de la Empresa</h2>
                    <button id="addEmpresaBtn" class="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg transition-colors">
                        <i class="fas fa-plus mr-2"></i>Configurar Empresa
                    </button>
                </div>

                <!-- Company content -->
                <div class="overflow-x-auto">
                    <table class="w-full table-auto">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Empresa</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">RUT</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Representante</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Teléfono</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Estado</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Acciones</th>
                            </tr>
                        </thead>
                        <tbody id="empresaTableBody" class="bg-white divide-y divide-gray-200">
                            <!-- Company data will be loaded here -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal for Add/Edit Forms -->
    <div id="modal" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden">
        <div class="flex items-start justify-center min-h-screen p-4 py-8">
            <div class="bg-white rounded-lg shadow-xl w-full max-w-4xl" style="max-height: 85vh; display: flex; flex-direction: column;">
                <div class="flex justify-between items-center p-6 border-b flex-shrink-0">
                    <h3 id="modalTitle" class="text-lg font-semibold text-gray-900">Formulario</h3>
                    <button id="closeModal" class="text-gray-400 hover:text-gray-600">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div id="modalContent" class="p-6 overflow-y-auto" style="flex: 1;">
                    <!-- Form content will be loaded here -->
                </div>
                <div id="modalButtons" class="p-6 border-t bg-gray-50 flex-shrink-0" style="display: none;">
                    <!-- Modal buttons will be moved here for long forms -->
                </div>
            </div>
        </div>
    </div>

    <!-- Loading Spinner -->
    <div id="loading" class="fixed inset-0 bg-white bg-opacity-75 z-40 hidden">
        <div class="flex items-center justify-center min-h-screen">
            <div class="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="js/data-service.js"></script>
    <script src="js/crud-system.js"></script>
</body>
</html>
